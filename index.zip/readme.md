# GPT Chatbot Webapp
간단한 GPT 챗봇 웹앱입니다.
- OpenAI API 연동
- 단일 질문 응답형
- index.html 열기만 하면 바로 실행 가능
